import { connectDB } from "@/lib/db";
import { authenticate } from "@/middleware/auth";
import Event from "@/models/Events";

export async function POST(req) {
  await connectDB();
  const auth = await authenticate(req);
  if (auth.status !== 200) {
    return new Response(JSON.stringify({ error: auth.message }), {
      status: auth.status,
    });
  }

  const user = auth.user;

  if (user.role !== "admin") {
    return new Response(
      JSON.stringify({ error: "Only admins can create events" }),
      { status: 403 }
    );
  }

  const { title, description, date, location } = await req.json();

  if (!title || !date) {
    return new Response(
      JSON.stringify({ error: "Title and date are required" }),
      { status: 400 }
    );
  }

  const newEvent = await Event.create({
    title,
    description,
    date,
    location,
    createdBy: user._id,
  });

  return new Response(
    JSON.stringify({ message: "Event created successfully" }),
    { status: 201 }
  );
}

export async function GET() {
  await connectDB();
  const events = await Event.find().sort({ date: 1 });
  return new Response(JSON.stringify(events), { status: 200 });
}
